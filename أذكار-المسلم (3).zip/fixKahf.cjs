const fs = require('fs');
let content = fs.readFileSync('src/data/azkar.ts', 'utf8');
content = content.replace(/export const kahfAzkar[\s\S]*$/, '');
fs.writeFileSync('src/data/azkar.ts', content);

const https = require('https');
https.get('https://api.alquran.cloud/v1/surah/18', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    const json = JSON.parse(data);
    const ayahs = json.data.ayahs.map(a => a.text.replace(/\n/g, '') + ' (' + a.numberInSurah + ')');
    let text = ayahs.join(' ');
    text = text.replace(/`/g, '\\`'); // escape backticks safely
    const newAddition = `\nexport const kahfAzkar: Zikr[] = [\n  {\n    id: 2001,\n    text: \`${text}\`,\n    reward: "من قرأ سورة الكهف في يوم الجمعة أضاء له من النور ما بين الجمعتين",\n    count: 1\n  }\n];\n`;
    fs.appendFileSync('src/data/azkar.ts', newAddition);
    console.log('Fixed kahfAzkar');
  });
});
