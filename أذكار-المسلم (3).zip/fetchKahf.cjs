const fs = require('fs');
const https = require('https');

https.get('https://api.alquran.cloud/v1/surah/18', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    const json = JSON.parse(data);
    const ayahs = json.data.ayahs.map(a => a.text + ' (' + a.numberInSurah + ')');
    let text = ayahs.join(' ');
    // remove weird unicode chars if any, keep arabic and symbols
    text = text.replace(/"/g, '\\"');
    const content = `\nexport const kahfAzkar: Zikr[] = [\n  {\n    id: 2001,\n    text: "${text}",\n    reward: "من قرأ سورة الكهف في يوم الجمعة أضاء له من النور ما بين الجمعتين",\n    count: 1\n  }\n];\n`;
    fs.appendFileSync('src/data/azkar.ts', content);
    console.log('Appended kahfAzkar to src/data/azkar.ts');
  });
});
