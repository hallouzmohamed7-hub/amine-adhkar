import React from 'react';
import { useStore, Theme, FontSize } from '../store/useStore';
import { Button } from './ui/Button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { X, Moon, Sun, Download, Upload, Trash2, SlidersHorizontal, Type, Bell, ExternalLink } from 'lucide-react';
import { cn } from '../lib/utils';
import { useState, useEffect } from 'react';

export function SettingsView({ onClose }: { onClose: () => void }) {
  const store = useStore();
  const [notificationStatus, setNotificationStatus] = useState<NotificationPermission | 'unknown'>('unknown');
  const isIframe = window.self !== window.top;

  useEffect(() => {
    if ('Notification' in window) {
      setNotificationStatus(Notification.permission);
    }
  }, []);

  const requestNotificationPermission = async () => {
    try {
      if (!('Notification' in window)) {
        alert("متصفحك أو هذا الإطار لا يدعم الإشعارات. جرب فتح التطبيق في علامة تبويب جديدة.");
        return;
      }
      
      if (window.self !== window.top) {
        alert("يرجى فتح التطبيق في شاشة كاملة (علامة تبويب جديدة) لتفعيل الإشعارات.");
        // Still try to request in case it's allowed
      }

      const permission = await Notification.requestPermission();
      setNotificationStatus(permission);
      
      if (permission === 'granted') {
        store.setNotificationsEnabled(true);
      } else {
        store.setNotificationsEnabled(false);
        alert("يرجى تفعيل خيار الإشعارات من إعدادات المتصفح");
      }
    } catch (error) {
      console.error("Error requesting notification permission:", error);
      alert("حدث خطأ أثناء طلب الإشعارات. يرجى فتح التطبيق في متصفح خارجي أو علامة تبويب جديدة.");
    }
  };

  const themes: { id: Theme; label: string; color: string }[] = [
    { id: 'lux-green', label: 'أخضر فاخر', color: 'bg-[#26631e]' },
    { id: 'blue', label: 'أزرق هادئ', color: 'bg-blue-600' },
    { id: 'purple', label: 'بنفسجي ملكي', color: 'bg-purple-600' },
  ];

  const fontSizes: { id: FontSize; label: string }[] = [
    { id: 'small', label: 'صغير' },
    { id: 'medium', label: 'متوسط' },
    { id: 'large', label: 'كبير' },
  ];

  const handleExport = () => {
    const data = localStorage.getItem('azkar-storage');
    const blob = new Blob([data || '{}'], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `azkar-backup-${new Date().getTime()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/json';
    input.onchange = (e: any) => {
      const file = e.target?.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          // Validating basic structure
          JSON.parse(content); 
          localStorage.setItem('azkar-storage', content);
          window.location.reload();
        } catch {
          alert("ملف غير صالح");
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  return (
    <div className="flex flex-col h-full bg-background absolute inset-0 z-50">
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur pb-4 pt-6 px-4 border-b flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-6 h-6" />
        </Button>
        <div className="text-lg font-semibold font-amiri">الإعدادات</div>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-20">
        
        {/* Appearance */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">المظهر</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <span>الوضع الليلي</span>
              <Button 
                variant="outline" 
                size="icon"
                onClick={store.toggleDarkMode}
              >
                {store.darkMode ? <Moon className="w-5 h-5 text-primary" /> : <Sun className="w-5 h-5 text-orange-500" />}
              </Button>
            </div>

            <div className="space-y-3">
              <span>السمة</span>
              <div className="flex gap-3">
                {themes.map(t => (
                  <button
                    key={t.id}
                    onClick={() => store.setTheme(t.id)}
                    className={cn(
                      "w-12 h-12 rounded-full flex items-center justify-center transition-all border-2",
                      t.color,
                      store.theme === t.id ? "ring-2 ring-offset-2 ring-primary border-white" : "border-transparent"
                    )}
                    aria-label={t.label}
                  />
                ))}
              </div>
            </div>

            <div className="space-y-3 pt-4 border-t border-border">
              <div className="flex items-center gap-2">
                <Type className="w-5 h-5 text-muted-foreground" />
                <span>حجم الأذكار</span>
              </div>
              <div className="flex gap-3">
                {fontSizes.map(f => (
                  <Button
                    key={f.id}
                    variant={store.fontSize === f.id ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => store.setFontSize(f.id)}
                  >
                    {f.label}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* App Installation */}
        {isIframe && (
          <Card className="border-primary border-2 bg-primary/5">
            <CardHeader>
              <CardTitle className="text-xl flex items-center gap-2">
                 تثبيت التطبيق والإشعارات
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm font-medium">
              <p>
                لحل مشكلة (403 خطأ) وتثبيت التطبيق على هاتفك بنجاح:
              </p>
              <ol className="list-decimal list-inside space-y-2 pr-2 text-muted-foreground mr-2">
                <li>في شاشة AI Studio الرئيسية (التي كنت فيها قبل قليل)، اضغط على زر <b>"مشاركة" (Share)</b> الموجود في أعلى اليمين.</li>
                <li>تأكد من تفعيل المشاركة وانسخ الرابط العام (Public Link).</li>
                <li>افتح متصفح <b>Chrome</b> في هاتفك، والصق الرابط الذي نسخته.</li>
                <li>بمجرد فتح التطبيق بشكل كامل، سيظهر لك زر <b>تثبيت التطبيق</b> في الشاشة الرئيسية للتطبيق، أو من القائمة الجانبية للمتصفح اختر <b>"إضافة إلى الشاشة الرئيسية"</b>.</li>
              </ol>
            </CardContent>
          </Card>
        )}

        {/* Notifications */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <Bell className="w-6 h-6" />
              تذكير الأذكار
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-base font-semibold">تفعيل الإشعارات</span>
              <button 
                onClick={() => {
                  if (store.notificationsEnabled) {
                    store.setNotificationsEnabled(false);
                  } else {
                    requestNotificationPermission();
                  }
                }}
                className={cn("w-12 h-6 rounded-full transition-colors relative", store.notificationsEnabled ? "bg-primary" : "bg-muted")}
              >
                <div className={cn("w-5 h-5 bg-white rounded-full absolute top-0.5 transition-all", store.notificationsEnabled ? "left-0.5" : "left-[26px]")} />
              </button>
            </div>

            {store.notificationsEnabled && (
              <div className="space-y-4 pt-4 border-t border-border">
                <div className="flex items-center justify-between">
                  <span>وقت أذكار الصباح</span>
                  <input 
                    type="time" 
                    value={store.morningNotificationTime}
                    onChange={(e) => store.setMorningNotificationTime(e.target.value)}
                    className="bg-primary/10 border border-primary/20 rounded-md p-2 text-center w-32 font-mono"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span>وقت أذكار المساء</span>
                  <input 
                    type="time" 
                    value={store.eveningNotificationTime}
                    onChange={(e) => store.setEveningNotificationTime(e.target.value)}
                    className="bg-primary/10 border border-primary/20 rounded-md p-2 text-center w-32 font-mono"
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Data Management */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">إدارة البيانات</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full justify-start gap-3" onClick={handleExport}>
              <Download className="w-5 h-5" />
              النسخ الاحتياطي (تصدير)
            </Button>
            <Button variant="outline" className="w-full justify-start gap-3" onClick={handleImport}>
              <Upload className="w-5 h-5" />
              استعادة البيانات (استيراد)
            </Button>
            <div className="pt-4 border-t">
              <Button variant="outline" className="w-full justify-start gap-3 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950" onClick={() => {
                if (confirm("هل أنت متأكد من مسح جميع التقدم والإحصائيات؟")) {
                  store.resetData();
                }
              }}>
                <Trash2 className="w-5 h-5" />
                مسح بيانات التطبيق
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
