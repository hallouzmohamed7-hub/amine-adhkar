import * as React from "react"
import { cn } from "@/src/lib/utils"

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'default' | 'outline' | 'ghost' | 'secondary';
  size?: 'default' | 'sm' | 'lg' | 'icon';
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'default', size = 'default', ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(
          "inline-flex items-center justify-center whitespace-nowrap rounded-2xl text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
          {
            'bg-[#064E3B] border border-primary text-primary-foreground hover:bg-[#065F46]': variant === 'default',
            'border border-primary text-primary hover:bg-primary/10': variant === 'outline',
            'hover:bg-primary/20 hover:text-primary': variant === 'ghost',
            'bg-primary/20 text-primary hover:bg-primary/30 border border-primary/30': variant === 'secondary',
            'h-12 px-6 py-3': size === 'default',
            'h-10 rounded-xl px-4': size === 'sm',
            'h-14 rounded-2xl px-10': size === 'lg',
            'h-12 w-12': size === 'icon',
          },
          className
        )}
        {...props}
      />
    )
  }
)
Button.displayName = "Button"

export { Button }
