import { useEffect, useRef } from 'react';
import { useStore } from '../store/useStore';
import { format } from 'date-fns';

export function useNotifications() {
  const store = useStore();
  const lastNotifiedRef = useRef<string | null>(null);

  useEffect(() => {
    if (!store.notificationsEnabled || !('Notification' in window) || Notification.permission !== 'granted') {
      return;
    }

    const checkTime = () => {
      const now = new Date();
      const currentTime = format(now, 'HH:mm');
      const storeLastNotified = localStorage.getItem('last-notified-time');

      const title = currentTime === store.morningNotificationTime ? 'وقت أذكار الصباح ☀️' : 'وقت أذكار المساء 🌙';
      const body = currentTime === store.morningNotificationTime ? 'حان الآن موعد قراءة أذكار الصباح' : 'حان الآن موعد قراءة أذكار المساء';
      const tag = currentTime === store.morningNotificationTime ? `morning-${currentTime}` : `evening-${currentTime}`;

      if (
        (currentTime === store.morningNotificationTime && storeLastNotified !== tag) ||
        (currentTime === store.eveningNotificationTime && storeLastNotified !== tag)
      ) {
        const showNotification = async () => {
          if ('serviceWorker' in navigator) {
            try {
              const registration = await navigator.serviceWorker.ready;
              await registration.showNotification(title, {
                body,
                icon: '/pwa-192x192.svg',
                vibrate: [200, 100, 200],
                tag: 'dhikr-reminder'
              } as NotificationOptions);
            } catch (err) {
              console.log('SW notification failed, falling back to standard', err);
              new Notification(title, { body, icon: '/pwa-192x192.svg' });
            }
          } else {
            new Notification(title, { body, icon: '/pwa-192x192.svg' });
          }
        };

        showNotification();
        localStorage.setItem('last-notified-time', tag);
        lastNotifiedRef.current = tag;
      }
    };

    // Check immediately and then every 30 seconds
    checkTime();
    const interval = setInterval(checkTime, 30000);

    return () => clearInterval(interval);
  }, [store.notificationsEnabled, store.morningNotificationTime, store.eveningNotificationTime]);
}
