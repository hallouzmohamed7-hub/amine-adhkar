import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { morningAzkar, eveningAzkar, mosqueAndPrayerAzkar, kahfAzkar, getDailyWird, Zikr } from '../data/azkar';
import { useStore } from '../store/useStore';
import { Button } from './ui/Button';
import { Card, CardContent } from './ui/Card';
import { CirclePlay, Pause, ChevronRight, CheckCircle2, Maximize, Minimize, Smartphone } from 'lucide-react';
import { cn } from '../lib/utils';

interface AzkarReadViewProps {
  type: 'morning' | 'evening' | 'wird' | 'mosque' | 'kahf';
  onClose: () => void;
}

export function AzkarReadView({ type, onClose }: AzkarReadViewProps) {
  const [azkars] = useState<Zikr[]>(() => {
    if (type === 'morning') return morningAzkar;
    if (type === 'evening') return eveningAzkar;
    if (type === 'mosque') return mosqueAndPrayerAzkar;
    if (type === 'kahf') return kahfAzkar;
    return getDailyWird();
  });
  const store = useStore();
  
  // Try to resume from progress if it matches
  const initialIndex = store.progress?.type === type ? store.progress.index : 0;
  
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [counts, setCounts] = useState<Record<number, number>>({});
  const [isPlaying, setIsPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isCssRotated, setIsCssRotated] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const currentZikr = azkars[currentIndex];

  // Calculate dynamic time based on length. Base 5s + 0.5s per 10 characters.
  const calculateInitialTime = (text: string) => {
    // Approx 2 seconds base + 1 second per 25 chars.
    const calculated = 2 + Math.floor(text.length / 25);
    // User speed preference acts as a maximum limit (5, 7, 10)
    return Math.min(store.autoScrollSpeed, calculated);
  };

  useEffect(() => {
    if (currentZikr) {
      setTimeLeft(calculateInitialTime(currentZikr.text));
    }
  }, [currentIndex, currentZikr, store.autoScrollSpeed]);

  useEffect(() => {
    // Save progress
    if (!completed) {
      store.saveProgress(type, currentIndex);
    }
  }, [currentIndex, type, completed]);

  const handleManualClick = (zikr: Zikr, idx: number) => {
    const currentCount = counts[zikr.id] || 0;
    if (currentCount >= zikr.count) return;

    const newCount = currentCount + 1;
    const newCounts = { ...counts, [zikr.id]: newCount };
    setCounts(newCounts);

    if (newCount >= zikr.count) {
      let nextIdx = currentIndex;
      if (idx === currentIndex) {
        // Move to the next uncompleted
        nextIdx = currentIndex + 1;
        while (nextIdx < azkars.length && (newCounts[azkars[nextIdx].id] || 0) >= azkars[nextIdx].count) {
          nextIdx++;
        }
        if (nextIdx < azkars.length) {
          setCurrentIndex(nextIdx);
        }
      }
      
      // Check if all are completed
      const allDone = azkars.every(z => (newCounts[z.id] || 0) >= z.count);
      if (allDone || nextIdx >= azkars.length) {
        setCompleted(true);
        setIsPlaying(false);
        store.markAzkarCompleted(type, azkars.length);
      }
    } else {
      if (idx === currentIndex) {
        setTimeLeft(calculateInitialTime(zikr.text));
      }
    }
  };

  useEffect(() => {
    let timer: number;
    if (isPlaying && timeLeft > 0 && !completed) {
      timer = window.setTimeout(() => setTimeLeft((prev) => Math.max(0, prev - 1)), 1000);
    } else if (isPlaying && timeLeft === 0 && !completed) {
       const currentCount = counts[currentZikr?.id || -1] || 0;
       if (currentZikr && currentCount < currentZikr.count) {
          handleManualClick(currentZikr, currentIndex);
       }
    }
    return () => clearTimeout(timer);
  }, [isPlaying, timeLeft, completed, currentIndex, counts, currentZikr]);

  const handleFullscreenToggle = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        if (window.screen && window.screen.orientation && window.screen.orientation.unlock) {
          window.screen.orientation.unlock();
        }
        setIsFullscreen(false);
      }
    } catch (error) {
      console.log("Fullscreen not supported", error);
      alert("عذراً، وضع ملء الشاشة غير مدعوم في متصفحك أو جهازك.");
    }
  };

  const handleRotateToggle = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setIsFullscreen(true);
      }
      
      let nativelyOriented = false;
      if (window.screen && window.screen.orientation && window.screen.orientation.lock) {
        try {
          if (window.screen.orientation.type.startsWith('portrait')) {
            await window.screen.orientation.lock('landscape');
          } else {
            await window.screen.orientation.lock('portrait');
          }
          nativelyOriented = true;
          setIsCssRotated(false); // Make sure CSS lock is off if native works
        } catch (lockError) {
          console.warn('Native orientation lock failed', lockError);
        }
      } 
      
      if (!nativelyOriented) {
        // Fallback to CSS rotation
        setIsCssRotated(prev => !prev);
      }
    } catch (e) {
      console.log('Orientation toggle full error', e);
      setIsCssRotated(prev => !prev);
    }
  };

  useEffect(() => {
    const el = scrollRef.current;
    if (!el || !isCssRotated) return;

    let startX = 0;
    let startY = 0;
    let startScrollTop = 0;
    let isDragging = false;
    let hasMoved = false;
    
    // For momentum physics
    let velocity = 0;
    let lastTime = 0;
    let animationFrameId: number;
    let timestamps: number[] = [];
    let xPositions: number[] = [];

    const handleTouchStart = (e: TouchEvent) => {
      cancelAnimationFrame(animationFrameId);
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      startScrollTop = el.scrollTop;
      isDragging = true;
      hasMoved = false;
      
      lastTime = performance.now();
      timestamps = [lastTime];
      xPositions = [startX];
      velocity = 0;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDragging) return;
      
      const currentX = e.touches[0].clientX;
      const currentY = e.touches[0].clientY;
      const moveX = currentX - startX;
      const moveY = currentY - startY;
      
      if (!hasMoved && Math.abs(moveX) < 5 && Math.abs(moveY) < 5) {
        return; // wait for intentional drag
      }
      
      hasMoved = true;
      if (e.cancelable) e.preventDefault(); 
      
      const currentTime = performance.now();
      el.scrollTop = startScrollTop + moveX;
      
      timestamps.push(currentTime);
      xPositions.push(currentX);
      
      while (timestamps.length > 0 && currentTime - timestamps[0] > 100) {
        timestamps.shift();
        xPositions.shift();
      }
    };

    const handleTouchEnd = () => {
      isDragging = false;
      
      if (!hasMoved) return;
      
      if (timestamps.length > 1) {
        const lastIndex = timestamps.length - 1;
        const firstIndex = 0;
        const dt = timestamps[lastIndex] - timestamps[firstIndex];
        const dx = xPositions[lastIndex] - xPositions[firstIndex];
        if (dt > 0) {
          velocity = dx / dt; 
        }
      }
      
      if (Math.abs(velocity) < 0.1) return;
      
      let currentVelocity = velocity;
      let lastFrameTime = performance.now();
      
      const step = (time: number) => {
        const dt = time - lastFrameTime;
        lastFrameTime = time;
        
        if (Math.abs(currentVelocity) < 0.05) return;
        
        el.scrollTop += currentVelocity * dt;
        // Friction reduces velocity smoothly over time
        currentVelocity *= Math.pow(0.996, dt); 
        
        if (el.scrollTop <= 0) {
            el.scrollTop = 0;
            return;
        }
        if (el.scrollTop >= el.scrollHeight - el.clientHeight) {
            el.scrollTop = el.scrollHeight - el.clientHeight;
            return;
        }
        
        animationFrameId = requestAnimationFrame(step);
      };
      
      animationFrameId = requestAnimationFrame(step);
    };

    const handleWheel = (e: WheelEvent) => {
      if (e.cancelable) e.preventDefault();
      cancelAnimationFrame(animationFrameId);
      el.scrollTop += e.deltaY;
    };

    el.addEventListener('touchstart', handleTouchStart, { passive: false });
    el.addEventListener('touchmove', handleTouchMove, { passive: false });
    el.addEventListener('touchend', handleTouchEnd);
    el.addEventListener('touchcancel', handleTouchEnd);
    el.addEventListener('wheel', handleWheel, { passive: false });

    return () => {
      cancelAnimationFrame(animationFrameId);
      el.removeEventListener('touchstart', handleTouchStart);
      el.removeEventListener('touchmove', handleTouchMove);
      el.removeEventListener('touchend', handleTouchEnd);
      el.removeEventListener('touchcancel', handleTouchEnd);
      el.removeEventListener('wheel', handleWheel);
    };
  }, [isCssRotated]);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  useEffect(() => {
    if (isFullscreen) {
      document.body.classList.add('is-fullscreen');
    } else {
      document.body.classList.remove('is-fullscreen');
    }
    return () => document.body.classList.remove('is-fullscreen');
  }, [isFullscreen]);

  if (completed) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center space-y-6">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", bounce: 0.5 }}
        >
          <CheckCircle2 className="w-32 h-32 text-primary mx-auto" />
        </motion.div>
        <h2 className="text-3xl font-amiri text-primary">تقبل الله طاعتكم</h2>
        <p className="text-muted-foreground">لقد أتممت {type === 'morning' ? 'أذكار الصباح' : type === 'evening' ? 'أذكار المساء' : type === 'mosque' ? 'دعاء المسجد والصلاة' : type === 'kahf' ? 'قراءة سورة الكهف' : 'ورد اليوم'} بنجاح.</p>
        <Button onClick={onClose} size="lg">العودة للرئيسية</Button>
      </div>
    );
  }

  return (
    <div className={cn("flex flex-col bg-background relative overflow-hidden transition-all duration-500", isCssRotated ? "css-landscape origin-center" : "h-full")}>
      {/* Header controls */}
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur pb-4 pt-6 px-4 border-b border-primary/20 flex items-center justify-between shadow-sm">
        <Button variant="ghost" size="icon" onClick={onClose} className="hover:bg-primary/20">
          <ChevronRight className="w-6 h-6" />
        </Button>
        <div className="text-lg font-semibold font-amiri text-white whitespace-nowrap overflow-hidden text-ellipsis flex-1 text-center">
          {type === 'morning' ? 'أذكار الصباح' : type === 'evening' ? 'أذكار المساء' : type === 'mosque' ? 'دعاء المسجد والصلاة' : type === 'kahf' ? 'سورة الكهف' : 'ورد اليوم'}
        </div>
        <div className="flex items-center gap-1 md:gap-2 overflow-x-auto">
          {type === 'kahf' && (
            <>
              <Button variant="outline" size="icon" onClick={handleRotateToggle} className={cn("mx-1 shrink-0 transition-colors", isCssRotated ? "bg-primary/20 border-primary" : "")} title="تدوير الشاشة">
                <Smartphone className="w-5 h-5 text-primary rotate-90" />
              </Button>
              <Button variant="outline" size="icon" onClick={handleFullscreenToggle} className={cn("mx-1 shrink-0", isFullscreen ? "bg-primary/20 border-primary" : "")} title="ملء الشاشة">
                {isFullscreen ? <Minimize className="w-5 h-5 text-primary" /> : <Maximize className="w-5 h-5 text-primary" />}
              </Button>
            </>
          )}
          <div className="flex items-center gap-1 mx-1 bg-primary/10 rounded-lg p-1">
            {[5, 7, 10].map(s => (
              <button
                key={s}
                onClick={() => store.setAutoScrollSpeed(s)}
                className={cn("px-1.5 md:px-2 py-1 text-xs md:text-sm font-bold rounded-md transition-colors",
                  store.autoScrollSpeed === s ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-primary/20"
                )}
              >
                {s}ث
              </button>
            ))}
          </div>
          {isPlaying && (
            <div className="font-mono text-lg md:text-xl text-primary font-bold min-w-[24px] text-center">
              {timeLeft}
            </div>
          )}
          <Button variant="outline" size="icon" onClick={() => setIsPlaying(!isPlaying)} className={isPlaying ? 'bg-primary/20 border-primary shrink-0' : 'shrink-0'}>
            {isPlaying ? <Pause className="w-5 h-5 text-primary" /> : <CirclePlay className="w-5 h-5 text-primary" />}
          </Button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-[#011F18] h-2">
        <div 
          className="bg-primary h-full transition-all duration-300"
          style={{ width: `${(currentIndex / azkars.length) * 100}%` }}
        />
      </div>

      {/* List of Azkars (Under each other) */}
      <div 
        className={cn("flex-1 overflow-y-auto px-4 py-8 space-y-6 pb-32", !isCssRotated && "scroll-smooth")} 
        ref={scrollRef}
        style={{ touchAction: isCssRotated ? 'none' : 'auto' }}
      >

        <AnimatePresence mode="popLayout">
          {azkars.map((zikr, idx) => {
            // Only show current and future (so they "ascend")
            if (idx < currentIndex - 1) return null; // keep one previous for smooth exit
            
            const isActive = idx === currentIndex;
            const isPast = idx < currentIndex;
            const targetCount = zikr.count;
            const currentCount = counts[zikr.id] || 0;
            const isZikrCompleted = currentCount >= targetCount;

            return (
              <motion.div
                key={zikr.id}
                layout
                initial={{ opacity: 0, y: 50 }}
                animate={{ 
                  opacity: isPast ? 0 : 1, 
                  scale: isActive ? 1 : 0.98,
                  y: 0 
                }}
                exit={{ opacity: 0, y: -50, scale: 0.9 }}
                transition={{ duration: 0.5, type: 'spring', bounce: 0.2 }}
                className={cn("transition-all", {
                  'pointer-events-none absolute opacity-0': isPast,
                })}
              >
                <Card 
                  onClick={() => handleManualClick(zikr, idx)}
                  className={cn("cursor-pointer transition-colors border max-w-2xl mx-auto w-full", {
                    'bg-[#064E3B] rounded-[32px] md:rounded-[48px] p-6 md:p-12 border-primary/20 shadow-2xl shadow-[#022c22]': isActive,
                    'bg-[#043325] border-primary/30 rounded-3xl p-6': !isActive && !isZikrCompleted,
                    'bg-[#022C22] border-primary/20 rounded-3xl p-6 opacity-80': isZikrCompleted && !isPast
                  })}
                >
                  <CardContent className="p-0 relative overflow-hidden flex flex-col items-center justify-center min-h-[300px]">
                    {/* Decorative Arabic Pattern Background (Abstract) */}
                    {isActive && (
                      <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
                        <span className="text-[200px] md:text-[300px] font-bold select-none text-white">ﷲ</span>
                      </div>
                    )}
                    
                    <div className="relative z-10 w-full text-center space-y-8 p-4">
                      <p className={cn("leading-relaxed font-quran whitespace-pre-wrap select-none transition-colors", {
                        "text-2xl md:text-4xl": store.fontSize === 'small',
                        "text-3xl md:text-5xl": store.fontSize === 'medium' || !store.fontSize,
                        "text-4xl md:text-6xl": store.fontSize === 'large',
                        "text-white drop-shadow-lg shadow-black/50": isActive,
                        "text-white/90 drop-shadow-md shadow-black/30": !isActive
                      })} style={{ lineHeight: '1.8' }}>
                        {zikr.text}
                      </p>
                      {zikr.reward && (
                        <p className={cn("italic font-semibold opacity-90", {
                          "text-base md:text-xl": store.fontSize === 'small',
                          "text-lg md:text-2xl": store.fontSize === 'medium' || !store.fontSize,
                          "text-xl md:text-3xl": store.fontSize === 'large',
                          "text-[#FBBF24] drop-shadow-md": isActive,
                          "text-[#FBBF24]/80": !isActive
                        })}>
                          {zikr.reward}
                        </p>
                      )}
                    </div>
                    
                    {/* Counter Area */}
                    <div className="flex flex-col items-center mt-8 w-full z-10 pb-4">
                      
                      {!isZikrCompleted ? (
                        <>
                          <button 
                            className={cn("rounded-full flex flex-col items-center justify-center mb-4 transition-all active:scale-95", {
                              "w-28 h-28 md:w-32 md:h-32 bg-[#FBBF24] shadow-[0_0_30px_rgba(251,191,36,0.4)] hover:shadow-[0_0_40px_rgba(251,191,36,0.5)] transform hover:scale-105": isActive,
                              "w-24 h-24 md:w-28 md:h-28 bg-[#FBBF24]/10 border-[3px] border-[#FBBF24]/40 hover:bg-[#FBBF24]/20": !isActive
                            })}
                            onClick={(e) => {
                               e.stopPropagation();
                               handleManualClick(zikr, idx);
                            }}
                          >
                            <span className={cn("font-bold font-amiri tracking-wider", {
                              "text-[#022C22]/80 text-2xl md:text-3xl": isActive,
                              "text-[#FBBF24]/80 text-xl md:text-2xl": !isActive
                            })}>
                              {currentCount} / {targetCount}
                            </span>
                          </button>

                          {isActive && isPlaying && (
                            <div className="w-full max-w-sm space-y-3 px-4">
                              <div className="flex justify-between text-[10px] md:text-xs text-[#34D399] px-1 uppercase tracking-tighter">
                                <span>الانتقال التلقائي</span>
                                <span>{timeLeft} ثانية متبقية</span>
                              </div>
                              <div className="w-full h-1.5 bg-[#022C22] rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-[#D97706] rounded-full transition-all duration-1000 ease-linear"
                                  style={{ width: `${100 - (timeLeft / calculateInitialTime(zikr.text)) * 100}%` }}
                                ></div>
                              </div>
                            </div>
                          )}
                        </>
                      ) : (
                        <div className="text-sm text-primary font-semibold py-2 border border-primary/20 bg-primary/10 px-6 rounded-full">
                          تم الانتهاء
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
