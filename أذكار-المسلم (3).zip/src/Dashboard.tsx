import React from 'react';
import { useStore } from '../store/useStore';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { Button } from './ui/Button';
import { Sun, Moon, Flame, Trophy, History, Settings, ExternalLink, BookOpen } from 'lucide-react';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import { usePWAInstall } from '../hooks/usePWAInstall';

export function Dashboard({ 
  onStart, 
  onOpenSettings,
  onOpenStats 
}: { 
  onStart: (type: 'morning' | 'evening' | 'wird' | 'mosque' | 'kahf') => void,
  onOpenSettings: () => void,
  onOpenStats: () => void
}) {
  const store = useStore();
  const today = format(new Date(), 'yyyy-MM-dd');
  const todayStats = store.stats[today];
  const { isInstallable, installPWA } = usePWAInstall();

  const hasMorning = todayStats?.completedMorning;
  const hasEvening = todayStats?.completedEvening;
  const hasWird = todayStats?.completedWird;

  return (
    <div className="flex flex-col min-h-screen">
      <div className="p-6 pb-20 max-w-4xl mx-auto w-full space-y-8">
        
        {/* Header Region */}
        <div className="flex justify-between items-center bg-[#011F18]/80 p-4 rounded-[24px] border border-primary/20 shadow-lg shadow-[#022c22] mt-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-emerald-800 rounded-2xl flex items-center justify-center shadow-lg shadow-[#022c22]">
              <Flame className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-sm text-primary uppercase tracking-widest leading-none mb-1">شعلة النشاط</p>
              <p className="text-xl font-bold text-white">{store.streak} <span className="text-sm font-normal text-muted-foreground">أيام</span></p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-left">
              <p className="text-sm text-primary uppercase tracking-widest leading-none mb-1 mr-2">المستوى {store.level}</p>
              <p className="text-lg font-bold text-white mr-2">{store.points} <span className="text-sm font-normal text-muted-foreground">نقطة</span></p>
            </div>
            <div className="w-12 h-12 bg-gradient-to-br from-primary to-emerald-800 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-[#022c22]">
              <Trophy className="w-6 h-6" />
            </div>
          </div>
        </div>

        <div className="text-center space-y-2 py-4">
          <h1 className="text-4xl font-amiri font-bold text-white tracking-tight">أذكار الروح</h1>
          <p className="text-primary">{format(new Date(), 'EEEE، d MMMM yyyy', { locale: ar })}</p>
        </div>

        {isInstallable && (
          <div className="bg-primary/20 border border-primary/40 rounded-xl p-4 flex items-center justify-between shadow-sm">
            <div>
              <p className="text-white font-medium">تثبيت التطبيق</p>
              <p className="text-sm text-primary">ثبّت التطبيق على جهازك للوصول السريع</p>
            </div>
            <Button onClick={installPWA} size="sm" className="gap-2">
              <ExternalLink className="w-4 h-4" />
              تثبيت
            </Button>
          </div>
        )}

        {/* Action Cards */}
        <div className="flex flex-col gap-6 w-full">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
            {/* Morning */}
            <Card 
              className="group cursor-pointer hover:border-primary hover:shadow-md transition-all overflow-hidden relative"
              onClick={() => onStart('morning')}
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Sun className="w-32 h-32 text-primary" />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-3xl text-white">أذكار الصباح</CardTitle>
                  {hasMorning && <div className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 rounded-full text-sm font-bold">مكتمل</div>}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">تبدأ من طلوع الفجر إلى الشروق</p>
                <Button className="w-full" variant={hasMorning ? "secondary" : "default"}>
                  {store.progress?.type === 'morning' ? 'إكمال القراءة' : 'ابدأ القراءة'}
                </Button>
              </CardContent>
            </Card>

            {/* Evening */}
            <Card 
              className="group cursor-pointer hover:border-primary hover:shadow-md transition-all overflow-hidden relative"
              onClick={() => onStart('evening')}
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Moon className="w-32 h-32 text-primary" />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-3xl text-white">أذكار المساء</CardTitle>
                  {hasEvening && <div className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 rounded-full text-sm font-bold">مكتمل</div>}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">تبدأ من صلاة العصر إلى الغروب</p>
                <Button className="w-full" variant={hasEvening ? "secondary" : "default"}>
                  {store.progress?.type === 'evening' ? 'إكمال القراءة' : 'ابدأ القراءة'}
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
            {/* Daily Wird */}
            <Card 
              className="group cursor-pointer hover:border-primary hover:shadow-md transition-all overflow-hidden relative"
              onClick={() => onStart('wird')}
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <BookOpen className="w-32 h-32 text-primary" />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-3xl text-white">ورد اليوم</CardTitle>
                  {hasWird && <div className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 rounded-full text-sm font-bold">مكتمل</div>}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">أذكار وتسابيح يومية لزيادة الرصيد من الحسنات</p>
                <Button className="w-full" variant={hasWird ? "secondary" : "default"}>
                  {store.progress?.type === 'wird' ? 'إكمال القراءة' : 'ابدأ القراءة'}
                </Button>
              </CardContent>
            </Card>

            {/* Mosque & Prayer */}
            <Card 
              className="group cursor-pointer hover:border-primary hover:shadow-md transition-all overflow-hidden relative"
              onClick={() => onStart('mosque')}
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <BookOpen className="w-32 h-32 text-primary" /> {/* Using BookOpen or another icon, will import below */}
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-2xl text-white">دعاء المسجد والصلاة</CardTitle>
                  {todayStats?.completedMosque && <div className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 rounded-full text-sm font-bold">مكتمل</div>}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">أذكار وأدعية الذهاب للمسجد والركوع والسجود</p>
                <Button className="w-full" variant={todayStats?.completedMosque ? "secondary" : "default"}>
                  {store.progress?.type === 'mosque' ? 'إكمال القراءة' : 'ابدأ القراءة'}
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 gap-6 w-full">
            {/* Surah Al-Kahf */}
            <Card 
              className="group cursor-pointer hover:border-primary hover:shadow-md transition-all overflow-hidden relative"
              onClick={() => onStart('kahf')}
            >
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <BookOpen className="w-32 h-32 text-primary" />
              </div>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-2xl text-white">قراءة سورة الكهف</CardTitle>
                  {todayStats?.completedKahf && <div className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 rounded-full text-sm font-bold">مكتمل</div>}
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">اقرأ سورة الكهف يوم الجمعة لفضلها العظيم.</p>
                <Button className="w-full" variant={todayStats?.completedKahf ? "secondary" : "default"}>
                  {store.progress?.type === 'kahf' ? 'إكمال القراءة' : 'ابدأ القراءة'}
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <Button variant="outline" className="h-24 flex flex-col gap-2" onClick={onOpenStats}>
            <History className="w-6 h-6" />
            الاحصائيات
          </Button>
          <Button variant="outline" className="h-24 flex flex-col gap-2" onClick={onOpenSettings}>
            <Settings className="w-6 h-6" />
            الإعدادات
          </Button>
        </div>
      </div>
    </div>
  );
}
