/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Dashboard } from './components/Dashboard';
import { AzkarReadView } from './components/AzkarReadView';
import { SettingsView } from './components/SettingsView';
import { StatsView } from './components/StatsView';
import { useStore } from './store/useStore';
import { useNotifications } from './hooks/useNotifications';
import { AnimatePresence, motion } from 'motion/react';
import { cn } from './lib/utils';

type ViewMode = 'dashboard' | 'read-morning' | 'read-evening' | 'read-wird' | 'read-mosque' | 'read-kahf' | 'settings' | 'stats';

export default function App() {
  const [view, setView] = useState<ViewMode>('dashboard');
  const store = useStore();

  useNotifications();

  useEffect(() => {
    // Apply theme classes to body
    document.documentElement.classList.remove('dark', 'lux-green', 'blue', 'purple');
    
    if (store.darkMode) {
      document.documentElement.classList.add('dark');
    }
    
    // Add custom theme color via CSS vars implicitly or explicit classes if needed
    // We already defined them inside @theme, but we can set a data attribute for overrides if needed
    document.documentElement.setAttribute('data-theme', store.theme);
  }, [store.darkMode, store.theme]);

  // (Removed basic Notification.requestPermission() as it is now in Settings)

  return (
    <div className={cn("min-h-screen bg-background/90 backdrop-blur-[2px] text-foreground transition-colors max-w-md mx-auto relative shadow-2xl overflow-hidden border-x border-border", store.theme)}>
      <AnimatePresence mode="wait">
        {view === 'dashboard' && (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="h-full min-h-screen"
          >
            <Dashboard 
              onStart={(type) => setView(`read-${type}` as ViewMode)}
              onOpenSettings={() => setView('settings')}
              onOpenStats={() => setView('stats')}
            />
          </motion.div>
        )}

        {(view === 'read-morning' || view === 'read-evening' || view === 'read-wird' || view === 'read-mosque' || view === 'read-kahf') && (
          <motion.div
            key="read"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="absolute inset-0 z-20 h-full bg-background/95 backdrop-blur-sm"
          >
            <AzkarReadView 
              type={view === 'read-morning' ? 'morning' : view === 'read-evening' ? 'evening' : view === 'read-mosque' ? 'mosque' : view === 'read-kahf' ? 'kahf' : 'wird'} 
              onClose={() => setView('dashboard')} 
            />
          </motion.div>
        )}

        {view === 'settings' && (
          <motion.div
            key="settings"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="absolute inset-0 z-30 bg-background/95 backdrop-blur-sm"
          >
            <SettingsView onClose={() => setView('dashboard')} />
          </motion.div>
        )}

        {view === 'stats' && (
          <motion.div
            key="stats"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="absolute inset-0 z-30 bg-background/95 backdrop-blur-sm"
          >
            <StatsView onClose={() => setView('dashboard')} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

