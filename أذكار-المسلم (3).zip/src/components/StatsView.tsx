import React from 'react';
import { useStore } from '../store/useStore';
import { Card, CardContent, CardHeader, CardTitle } from './ui/Card';
import { Button } from './ui/Button';
import { X, TrendingUp, Calendar as CalendarIcon, Award } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { format, subDays, parseISO } from 'date-fns';
import { ar } from 'date-fns/locale';

export function StatsView({ onClose }: { onClose: () => void }) {
  const store = useStore();

  // Generate last 7 days stats
  const last7Days = Array.from({ length: 7 }).map((_, i) => {
    const d = subDays(new Date(), 6 - i);
    const dateStr = format(d, 'yyyy-MM-dd');
    const stat = store.stats[dateStr];
    return {
      name: format(d, 'EEEE', { locale: ar }).split(' ')[0], // short day name
      total: stat?.totalAzkarsRead || 0,
      fullDate: dateStr,
      morning: stat?.completedMorning ? 1 : 0,
      evening: stat?.completedEvening ? 1 : 0,
    };
  });

  const totalAzkarsReadEver = Object.values(store.stats).reduce((acc, curr) => acc + curr.totalAzkarsRead, 0);

  return (
    <div className="flex flex-col h-full bg-background absolute inset-0 z-50">
      <div className="sticky top-0 z-10 bg-background/90 backdrop-blur pb-4 pt-6 px-4 border-b flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-6 h-6" />
        </Button>
        <div className="text-lg font-semibold font-amiri">الإحصائيات والتقدم</div>
        <div className="w-10"></div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-20">
        
        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="p-4 flex flex-col items-center justify-center text-center space-y-2">
              <Award className="w-8 h-8 text-primary" />
              <p className="text-sm text-muted-foreground">المستوى الحالي</p>
              <p className="text-2xl font-bold">{store.level}</p>
            </CardContent>
          </Card>
          <Card className="bg-orange-50 dark:bg-orange-950 border-orange-200 dark:border-orange-900">
            <CardContent className="p-4 flex flex-col items-center justify-center text-center space-y-2">
              <TrendingUp className="w-8 h-8 text-orange-500" />
              <p className="text-sm text-muted-foreground text-orange-600 dark:text-orange-400">إجمالي الأذكار</p>
              <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">{totalAzkarsReadEver}</p>
            </CardContent>
          </Card>
        </div>

        {/* Activity Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-primary" />
              نشاط آخر 7 أيام
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full mt-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={last7Days}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: 'currentColor', fontSize: 12 }} 
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: 'currentColor', fontSize: 12 }}
                  />
                  <Tooltip 
                    cursor={{ fill: 'rgba(0,0,0,0.05)' }}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                  />
                  <Bar 
                    dataKey="total" 
                    fill="var(--color-lux-500)" 
                    radius={[4, 4, 0, 0]} 
                    name="عدد الأذكار"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
