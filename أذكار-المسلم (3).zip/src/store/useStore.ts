import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { format, isSameDay, subDays } from 'date-fns';

export type Theme = 'lux-green' | 'dark' | 'light' | 'blue' | 'purple';
export type Language = 'ar' | 'en';
export type FontSize = 'small' | 'medium' | 'large';

export interface DailyStat {
  date: string;
  completedMorning: boolean;
  completedEvening: boolean;
  completedWird?: boolean;
  completedMosque?: boolean;
  completedKahf?: boolean;
  totalAzkarsRead: number;
}

interface AppState {
  theme: Theme;
  language: Language;
  fontSize: FontSize;
  darkMode: boolean;
  progress: { type: 'morning' | 'evening' | 'wird' | 'mosque' | 'kahf'; index: number } | null;
  stats: Record<string, DailyStat>; // Keyed by YYYY-MM-DD
  streak: number;
  lastActiveDate: string | null;
  points: number;
  level: number;
  autoScrollSpeed: number; // base seconds
  notificationsEnabled: boolean;
  morningNotificationTime: string; // HH:mm
  eveningNotificationTime: string; // HH:mm
  
  // Actions
  setTheme: (theme: Theme) => void;
  setLanguage: (lang: Language) => void;
  setFontSize: (size: FontSize) => void;
  toggleDarkMode: () => void;
  saveProgress: (type: 'morning' | 'evening' | 'wird' | 'mosque' | 'kahf', index: number) => void;
  clearProgress: () => void;
  markAzkarCompleted: (type: 'morning' | 'evening' | 'wird' | 'mosque' | 'kahf', count: number) => void;
  setAutoScrollSpeed: (speed: number) => void;
  setNotificationsEnabled: (enabled: boolean) => void;
  setMorningNotificationTime: (time: string) => void;
  setEveningNotificationTime: (time: string) => void;
  resetData: () => void;
}

const calculateLevel = (points: number) => {
  return Math.floor(Math.sqrt(points / 100)) + 1;
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      theme: 'lux-green',
      language: 'ar',
      fontSize: 'medium',
      darkMode: false,
      progress: null,
      stats: {},
      streak: 0,
      lastActiveDate: null,
      points: 0,
      level: 1,
      autoScrollSpeed: 5,
      notificationsEnabled: false,
      morningNotificationTime: '06:00',
      eveningNotificationTime: '16:00',

      setTheme: (theme) => set({ theme }),
      setLanguage: (language) => set({ language }),
      setFontSize: (size) => set({ fontSize: size }),
      toggleDarkMode: () => set((state) => ({ darkMode: !state.darkMode })),
      saveProgress: (type, index) => set({ progress: { type, index } }),
      clearProgress: () => set({ progress: null }),
      
      markAzkarCompleted: (type, count) => {
        set((state) => {
          const today = format(new Date(), 'yyyy-MM-dd');
          const yesterday = format(subDays(new Date(), 1), 'yyyy-MM-dd');
          
          let newStreak = state.streak;
          
          // Streak logic
          if (state.lastActiveDate === yesterday) {
            newStreak += 1;
          } else if (state.lastActiveDate !== today) {
            newStreak = 1;
          }

          const currentStat = state.stats[today] || {
            date: today,
            completedMorning: false,
            completedEvening: false,
            completedWird: false,
            completedMosque: false,
            completedKahf: false,
            totalAzkarsRead: 0,
          };

          const updatedStat = {
            ...currentStat,
            completedMorning: type === 'morning' ? true : currentStat.completedMorning,
            completedEvening: type === 'evening' ? true : currentStat.completedEvening,
            completedWird: type === 'wird' ? true : currentStat.completedWird,
            completedMosque: type === 'mosque' ? true : currentStat.completedMosque,
            completedKahf: type === 'kahf' ? true : currentStat.completedKahf,
            totalAzkarsRead: currentStat.totalAzkarsRead + count,
          };

          const newPoints = state.points + (count * 2) + 50; // 2 points per Zikr, 50 bonus for finishing

          return {
            stats: { ...state.stats, [today]: updatedStat },
            streak: newStreak,
            lastActiveDate: today,
            points: newPoints,
            level: calculateLevel(newPoints),
            progress: null, // clear progress on completion
          };
        });
      },
      setAutoScrollSpeed: (speed) => set({ autoScrollSpeed: speed }),
      setNotificationsEnabled: (enabled) => set({ notificationsEnabled: enabled }),
      setMorningNotificationTime: (time) => set({ morningNotificationTime: time }),
      setEveningNotificationTime: (time) => set({ eveningNotificationTime: time }),
      resetData: () => set({ stats: {}, streak: 0, lastActiveDate: null, points: 0, level: 1, progress: null }),
    }),
    {
      name: 'azkar-storage',
    }
  )
);
